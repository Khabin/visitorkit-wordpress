# Changelog

#### 1.0.0 - April 22, 2021

Plugin release.
